from telethon.sync import TelegramClient
from telethon.sessions import StringSession
import os
APP_ID = os.environ.get("APP_ID")
APP_HASH = os.environ.get("APP_HASH")
session1 = os.environ.get("TERMUX")
SESSION1 = os.environ.get("TERMUX")
DEVLOO = os.environ.get("DEVLO")
CHNA = os.environ.get("CHNA")
TG_BOT_USERNAME = os.environ.get("TG_BOT_USERNAME")
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN")
abbas = TelegramClient(StringSession(session1), APP_ID, APP_HASH)
ispay = ['yes']
ispay2 = ['yes']

